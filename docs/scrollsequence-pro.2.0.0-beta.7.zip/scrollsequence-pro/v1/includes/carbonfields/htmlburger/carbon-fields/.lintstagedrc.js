module.exports = {
	'packages/**/*.js': [
		'eslint'
	]
};
